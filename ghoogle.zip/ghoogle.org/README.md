# Ghoogle

A simple proxy using TIW Ultraviolet Static, allowing users to search anything completly unblocked.

## Features
- Search functionality
- Built-in proxy service using Ultraviolet
- Looks and feels like Google

## Setup
1. Clone this repository
2. Deploy to a static hosting service
3. Access through your web browser

## License
See [LICENSE](LICENSE) file for details.
Fireworks animation by [kirilv.com](https://www.kirilv.com/canvas-confetti)

All rights reserved. Google™, Google logo™, and any related trademarks are the property of Google LLC. I do not claim ownership of any trademarks or logos mentioned.
